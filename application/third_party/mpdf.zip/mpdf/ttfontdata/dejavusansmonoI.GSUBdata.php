<?php
$GSLuCoverage = array (
  0 => 
  array (
    0 => 
    array (
      350 => 0,
      351 => 1,
      354 => 2,
      355 => 3,
    ),
  ),
  1 => 
  array (
    0 => 
    array (
      1073 => 0,
    ),
  ),
  2 => 
  array (
    0 => 
    array (
      330 => 0,
    ),
  ),
  3 => 
  array (
    0 => 
    array (
      102 => 0,
    ),
  ),
);
?>
<?php
$name='DejaVuSansMono-Oblique';
$type='TTF';
$desc=array (
  'CapHeight' => 729,
  'XHeight' => 547,
  'FontBBox' => '[-403 -375 746 1028]',
  'Flags' => 69,
  'Ascent' => 928,
  'Descent' => -236,
  'Leading' => 0,
  'ItalicAngle' => -11,
  'StemV' => 87,
  'MissingWidth' => 602,
);
$unitsPerEm=2048;
$up=-63;
$ut=44;
$strp=259;
$strs=50;
$ttffile='F:/xampp/htdocs/projects/voyager-med/application/third_party/mpdf/ttfonts/DejaVuSansMono-Oblique.ttf';
$TTCfontID='0';
$originalsize=230244;
$sip=false;
$smp=false;
$BMPselected=true;
$fontkey='dejavusansmonoI';
$panose=' 0 0 2 b 6 9 3 3 4 b 2 4';
$haskerninfo=false;
$haskernGPOS=false;
$hassmallcapsGSUB=false;
$fontmetrics='win';
// TypoAscender/TypoDescender/TypoLineGap = 760, -240, 200
// usWinAscent/usWinDescent = 928, -236
// hhea Ascent/Descent/LineGap = 928, -236, 0
$useOTL=255;
$rtlPUAstr='';
$GSUBScriptLang=array (
  'cyrl' => 'SRB  ',
  'latn' => 'DFLT ISM  KSM  LSM  MOL  NSM  ROM  SKS  SSM  ',
);
$GSUBFeatures=array (
  'cyrl' => 
  array (
    'SRB ' => 
    array (
      'locl' => 
      array (
        0 => 1,
      ),
    ),
  ),
  'latn' => 
  array (
    'DFLT' => 
    array (
      'dlig' => 
      array (
        0 => 3,
      ),
    ),
    'ISM ' => 
    array (
      'locl' => 
      array (
        0 => 2,
      ),
      'dlig' => 
      array (
        0 => 3,
      ),
    ),
    'KSM ' => 
    array (
      'locl' => 
      array (
        0 => 2,
      ),
      'dlig' => 
      array (
        0 => 3,
      ),
    ),
    'LSM ' => 
    array (
      'locl' => 
      array (
        0 => 2,
      ),
      'dlig' => 
      array (
        0 => 3,
      ),
    ),
    'MOL ' => 
    array (
      'locl' => 
      array (
        0 => 0,
      ),
      'dlig' => 
      array (
        0 => 3,
      ),
    ),
    'NSM ' => 
    array (
      'locl' => 
      array (
        0 => 2,
      ),
      'dlig' => 
      array (
        0 => 3,
      ),
    ),
    'ROM ' => 
    array (
      'locl' => 
      array (
        0 => 0,
      ),
      'dlig' => 
      array (
        0 => 3,
      ),
    ),
    'SKS ' => 
    array (
      'locl' => 
      array (
        0 => 2,
      ),
      'dlig' => 
      array (
        0 => 3,
      ),
    ),
    'SSM ' => 
    array (
      'locl' => 
      array (
        0 => 2,
      ),
      'dlig' => 
      array (
        0 => 3,
      ),
    ),
  ),
);
$GSUBLookups=array (
  0 => 
  array (
    'Type' => 1,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 1338,
    ),
    'MarkFilteringSet' => '',
  ),
  1 => 
  array (
    'Type' => 1,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 1364,
    ),
    'MarkFilteringSet' => '',
  ),
  2 => 
  array (
    'Type' => 1,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 1376,
    ),
    'MarkFilteringSet' => '',
  ),
  3 => 
  array (
    'Type' => 4,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 1388,
    ),
    'MarkFilteringSet' => '',
  ),
);
$GPOSScriptLang=array (
  'cyrl' => 'DFLT ',
  'lao ' => 'DFLT ',
  'latn' => 'DFLT ',
);
$GPOSFeatures=array (
  'lao ' => 
  array (
    'DFLT' => 
    array (
      'mark' => 
      array (
        0 => 0,
      ),
    ),
  ),
);
$GPOSLookups=array (
  0 => 
  array (
    'Type' => 4,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 484,
    ),
    'MarkFilteringSet' => '',
  ),
);
?>